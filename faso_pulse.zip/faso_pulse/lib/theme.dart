import 'package:flutter/material.dart';

const Color kBlueLight = Color(0xFFF0F8FF);
const Color kRed = Color(0xFFD32F2F);
const Color kText = Color(0xFF1E293B);

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

final ThemeData lightTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.light,
  scaffoldBackgroundColor: kBlueLight,
  cardColor: Colors.white,
  colorScheme: ColorScheme.fromSeed(seedColor: kRed, primary: kRed, brightness: Brightness.light),
  textTheme: ThemeData.light().textTheme.apply(bodyColor: kText, displayColor: kText),
  appBarTheme: const AppBarTheme(
    backgroundColor: kBlueLight,
    foregroundColor: kText,
    elevation: 0,
    centerTitle: false,
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: Colors.white,
    selectedItemColor: kRed,
    unselectedItemColor: Colors.grey,
  ),
);

final ThemeData darkTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color(0xFF0F172A),
  cardColor: const Color(0xFF1E293B),
  colorScheme: ColorScheme.fromSeed(seedColor: kRed, primary: kRed, brightness: Brightness.dark),
  appBarTheme: const AppBarTheme(
    backgroundColor: Color(0xFF0F172A),
    foregroundColor: Colors.white,
    elevation: 0,
    centerTitle: false,
  ),
  bottomNavigationBarTheme: const BottomNavigationBarThemeData(
    backgroundColor: Color(0xFF1E293B),
    selectedItemColor: kRed,
    unselectedItemColor: Colors.grey,
  ),
);

BoxDecoration cardDecoration(BuildContext context, {double radius = 18}) {
  return BoxDecoration(
    color: Theme.of(context).cardColor,
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.07),
        blurRadius: 14,
        offset: const Offset(0, 5),
      ),
    ],
  );
}
