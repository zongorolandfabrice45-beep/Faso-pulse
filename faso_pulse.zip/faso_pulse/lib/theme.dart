import 'package:flutter/material.dart';

const Color kBlue = Color(0xFF1565C0);
const Color kBlueDark = Color(0xFF0D47A1);
const Color kBg = Color(0xFFF2F6FB);
const Color kText = Color(0xFF1E293B);

final ValueNotifier<ThemeMode> themeNotifier = ValueNotifier(ThemeMode.light);

final ThemeData lightTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.light,
  scaffoldBackgroundColor: kBg,
  cardColor: Colors.white,
  colorScheme: ColorScheme.fromSeed(
    seedColor: kBlue,
    primary: kBlue,
    brightness: Brightness.light,
  ),
  textTheme: ThemeData.light().textTheme.apply(bodyColor: kText, displayColor: kText),
);

final ThemeData darkTheme = ThemeData(
  useMaterial3: true,
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color(0xFF0F172A),
  cardColor: const Color(0xFF1E293B),
  colorScheme: ColorScheme.fromSeed(
    seedColor: kBlue,
    primary: const Color(0xFF42A5F5),
    brightness: Brightness.dark,
  ),
);

Color accentOf(BuildContext context) => Theme.of(context).colorScheme.primary;

BoxDecoration cardDecoration(BuildContext context, {double radius = 18}) {
  return BoxDecoration(
    color: Theme.of(context).cardColor,
    borderRadius: BorderRadius.circular(radius),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.07),
        blurRadius: 14,
        offset: const Offset(0, 5),
      ),
    ],
  );
}
