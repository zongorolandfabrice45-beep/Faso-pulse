class VideoItem {
  final String title;
  final String channel;
  final String thumbnailUrl;
  final String avatarUrl;
  final String duration;
  final String views;
  final String time;
  final String url;

  const VideoItem({
    required this.title,
    required this.channel,
    required this.thumbnailUrl,
    required this.avatarUrl,
    required this.duration,
    required this.views,
    required this.time,
    required this.url,
  });
}
