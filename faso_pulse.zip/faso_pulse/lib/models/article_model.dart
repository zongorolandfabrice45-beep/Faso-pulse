class Article {
  final String title;
  final String category;
  final String imageUrl;
  final String source;
  final String time;

  const Article({
    required this.title,
    required this.category,
    required this.imageUrl,
    required this.source,
    required this.time,
  });
}
