import '../models/article_model.dart';
import '../models/video_model.dart';

const _sport = 'https://images.unsplash.com/photo-1431324155629-1a6deb1dec8d?w=800&q=80';
const _culture = 'https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?w=800&q=80';
const _politique = 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=800&q=80';
const _eco = 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80';
const _musique = 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=800&q=80';
const _avatar = 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200&q=80';

const List<Article> mockArticles = [
  Article(
    title: 'Les Étalons préparent leur prochain grand rendez-vous continental',
    category: 'Sport',
    imageUrl: _sport,
    source: 'Faso Sport',
    time: 'Il y a 1 h',
  ),
  Article(
    title: 'FESPACO : le cinéma africain à l\'honneur à Ouagadougou',
    category: 'Culture',
    imageUrl: _culture,
    source: 'Faso Culture',
    time: 'Il y a 3 h',
  ),
  Article(
    title: 'Politique : les grandes annonces de la semaine',
    category: 'Politique',
    imageUrl: _politique,
    source: 'Faso Info',
    time: 'Il y a 5 h',
  ),
  Article(
    title: 'Économie : les jeunes entrepreneurs burkinabè innovent',
    category: 'Économie',
    imageUrl: _eco,
    source: 'Faso Eco',
    time: 'Il y a 8 h',
  ),
  Article(
    title: 'Musique : la nouvelle scène burkinabè séduit l\'Afrique de l\'Ouest',
    category: 'Musique',
    imageUrl: _musique,
    source: 'Faso Culture',
    time: 'Hier',
  ),
];

const List<VideoItem> mockVideos = [
  VideoItem(
    title: 'Résumé du match : les Étalons en action',
    channel: 'Faso Sport TV',
    thumbnailUrl: _sport,
    avatarUrl: _avatar,
    duration: '12:34',
    views: '120 k vues',
    time: 'il y a 2 jours',
  ),
  VideoItem(
    title: 'Reportage : à la découverte du marché de Ouagadougou',
    channel: 'Faso Culture TV',
    thumbnailUrl: _culture,
    avatarUrl: _avatar,
    duration: '08:21',
    views: '45 k vues',
    time: 'il y a 4 jours',
  ),
  VideoItem(
    title: 'Débat : quel avenir pour la jeunesse ?',
    channel: 'Faso Info TV',
    thumbnailUrl: _politique,
    avatarUrl: _avatar,
    duration: '25:10',
    views: '78 k vues',
    time: 'il y a 1 semaine',
  ),
  VideoItem(
    title: 'Concert : la nuit de la musique à Bobo-Dioulasso',
    channel: 'Faso Music',
    thumbnailUrl: _musique,
    avatarUrl: _avatar,
    duration: '45:02',
    views: '230 k vues',
    time: 'il y a 2 semaines',
  ),
];
