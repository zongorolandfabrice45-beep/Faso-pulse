import 'package:flutter/foundation.dart';
import '../models/article_model.dart';

final ValueNotifier<List<Article>> savedArticles = ValueNotifier<List<Article>>([]);

bool isSaved(Article a) => savedArticles.value.any((x) => x.title == a.title);

void toggleSaved(Article a) {
  final list = List<Article>.from(savedArticles.value);
  final i = list.indexWhere((x) => x.title == a.title);
  if (i >= 0) {
    list.removeAt(i);
  } else {
    list.add(a);
  }
  savedArticles.value = list;
}
