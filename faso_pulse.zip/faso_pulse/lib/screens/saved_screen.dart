import 'package:flutter/material.dart';
import '../data/saved_store.dart';
import '../models/article_model.dart';
import '../widgets/article_card.dart';
import '../widgets/section_header.dart';

class SavedScreen extends StatelessWidget {
  const SavedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SectionHeader(title: 'Enregistrés', icon: Icons.bookmark_border),
        Expanded(
          child: ValueListenableBuilder<List<Article>>(
            valueListenable: savedArticles,
            builder: (_, list, __) {
              if (list.isEmpty) {
                return const Center(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Text(
                      "Aucun article enregistré.\nOuvre un article et touche le marque-page pour l'ajouter ici.",
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 16, color: Colors.grey),
                    ),
                  ),
                );
              }
              return ListView(
                padding: const EdgeInsets.only(top: 8, bottom: 16),
                children: [for (final a in list) ArticleCard(article: a)],
              );
            },
          ),
        ),
      ],
    );
  }
}
