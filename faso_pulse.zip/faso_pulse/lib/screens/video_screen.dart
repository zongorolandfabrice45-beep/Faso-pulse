import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../theme.dart';
import '../widgets/youtube_video_card.dart';

class VideoScreen extends StatelessWidget {
  const VideoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Vidéos',
          style: TextStyle(color: kRed, fontWeight: FontWeight.w800, fontSize: 24),
        ),
      ),
      body: ListView.builder(
        padding: const EdgeInsets.only(bottom: 16),
        itemCount: mockVideos.length,
        itemBuilder: (_, i) => YoutubeVideoCard(video: mockVideos[i]),
      ),
    );
  }
}
