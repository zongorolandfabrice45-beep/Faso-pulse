import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../widgets/section_header.dart';
import '../widgets/youtube_video_card.dart';

class VideoScreen extends StatelessWidget {
  const VideoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SectionHeader(title: 'Vidéos', icon: Icons.video_library_outlined),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.only(bottom: 16),
            itemCount: mockVideos.length,
            itemBuilder: (_, i) => YoutubeVideoCard(video: mockVideos[i]),
          ),
        ),
      ],
    );
  }
}
