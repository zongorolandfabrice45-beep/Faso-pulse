import 'package:flutter/material.dart';
import '../data/saved_store.dart';
import '../models/article_model.dart';
import '../theme.dart';
import '../widgets/net_image.dart';

class ArticleDetailScreen extends StatelessWidget {
  final Article article;
  const ArticleDetailScreen({super.key, required this.article});

  @override
  Widget build(BuildContext context) {
    final accent = accentOf(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: kBlue,
        foregroundColor: Colors.white,
        title: const Text('Faso Pulse', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          ValueListenableBuilder<List<Article>>(
            valueListenable: savedArticles,
            builder: (_, __, ___) => IconButton(
              icon: Icon(isSaved(article) ? Icons.bookmark : Icons.bookmark_border),
              onPressed: () => toggleSaved(article),
            ),
          ),
        ],
      ),
      body: ListView(
        children: [
          NetImage(url: article.imageUrl, width: double.infinity, height: 240),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  article.category.toUpperCase(),
                  style: TextStyle(
                    color: accent,
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  article.title,
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 8),
                Text(
                  'Par : ${article.source}  •  ${article.time}',
                  style: const TextStyle(color: Colors.grey),
                ),
                const SizedBox(height: 16),
                Text(
                  article.description,
                  style: const TextStyle(fontSize: 17, height: 1.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
