import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../models/article_model.dart';
import '../screens/article_detail_screen.dart';
import '../theme.dart';
import '../widgets/article_card.dart';
import '../widgets/net_image.dart';
import '../widgets/section_header.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _cat = 'Tout';

  Widget _featured(BuildContext context, Article a) {
    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ArticleDetailScreen(article: a)),
      ),
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 4, 16, 12),
        decoration: cardDecoration(context, radius: 20),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                NetImage(url: a.imageUrl, width: double.infinity, height: 200),
                Positioned(
                  left: 12,
                  top: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: accentOf(context),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text(
                      'À LA UNE',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    a.title,
                    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '${a.source} • ${a.time}',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = accentOf(context);
    final cats = ['Tout', ...{for (final a in mockArticles) a.category}];
    final list = _cat == 'Tout'
        ? mockArticles
        : mockArticles.where((a) => a.category == _cat).toList();

    return Column(
      children: [
        const SectionHeader(title: 'Accueil', icon: Icons.newspaper),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 16),
            children: [
              SizedBox(
                height: 58,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                  children: [
                    for (final c in cats)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(c),
                          selected: _cat == c,
                          showCheckmark: false,
                          selectedColor: accent,
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _cat == c ? Colors.white : null,
                          ),
                          onSelected: (_) => setState(() => _cat = c),
                        ),
                      ),
                  ],
                ),
              ),
              if (list.isNotEmpty) _featured(context, list.first),
              for (final a in list.skip(1)) ArticleCard(article: a),
            ],
          ),
        ),
      ],
    );
  }
}
