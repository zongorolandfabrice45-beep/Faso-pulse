import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/section_header.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notif = true;
  String _lang = 'FR';

  static const Map<String, String> _langs = {
    'English': 'EN',
    'Français': 'FR',
    'Deutsch': 'DE',
    'Español': 'ES',
  };

  Widget _title(String text) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 10),
        child: Text(text, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      );

  Widget _card(Widget child) => Container(
        decoration: cardDecoration(context, radius: 14),
        child: child,
      );

  Widget _tile(IconData icon, String title, String body) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: cardDecoration(context, radius: 14),
        child: ListTile(
          leading: Icon(icon),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: Text(title),
              content: Text(body),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Fermer'),
                ),
              ],
            ),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final accent = accentOf(context);
    return Column(
      children: [
        const SectionHeader(title: 'Paramètres', icon: Icons.person_outline),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _title('Notifications'),
              _card(
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_none),
                  title: const Text('Statut de notification'),
                  value: _notif,
                  onChanged: (v) => setState(() => _notif = v),
                ),
              ),
              _title('Apparence'),
              _card(
                ValueListenableBuilder<ThemeMode>(
                  valueListenable: themeNotifier,
                  builder: (_, mode, __) => SwitchListTile(
                    secondary: const Icon(Icons.dark_mode_outlined),
                    title: const Text('Mode sombre'),
                    value: mode == ThemeMode.dark,
                    onChanged: (v) =>
                        themeNotifier.value = v ? ThemeMode.dark : ThemeMode.light,
                  ),
                ),
              ),
              _title('Langue'),
              _card(
                ListTile(
                  leading: const Icon(Icons.language),
                  title: const Text('Langue'),
                  subtitle: Text('Actuelle : $_lang'),
                ),
              ),
              const SizedBox(height: 12),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    for (final e in _langs.entries)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ChoiceChip(
                          label: Text(e.key),
                          selected: _lang == e.value,
                          showCheckmark: false,
                          selectedColor: accent,
                          labelStyle: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: _lang == e.value ? Colors.white : null,
                          ),
                          onSelected: (_) => setState(() => _lang = e.value),
                        ),
                      ),
                  ],
                ),
              ),
              _title('Mentions légales'),
              _tile(Icons.help_outline, 'Contactez-nous', 'Coordonnées à renseigner.'),
              _tile(Icons.language, 'Site web', 'Adresse du site à renseigner.'),
              _tile(Icons.info_outline, 'À propos', 'Faso Pulse v1.0.0 - actualités et vidéos du Burkina Faso.'),
              _tile(Icons.privacy_tip_outlined, 'Politique de confidentialité', 'Texte à renseigner.'),
              const SizedBox(height: 16),
              const Center(
                child: Text('Tous droits réservés © 2026', style: TextStyle(color: Colors.grey)),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ],
    );
  }
}
