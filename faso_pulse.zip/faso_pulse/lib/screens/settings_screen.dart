import 'package:flutter/material.dart';
import '../theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Paramètres',
          style: TextStyle(color: kRed, fontWeight: FontWeight.w800, fontSize: 24),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            decoration: cardDecoration(context),
            child: ValueListenableBuilder<ThemeMode>(
              valueListenable: themeNotifier,
              builder: (_, mode, __) => SwitchListTile(
                activeColor: kRed,
                secondary: const Icon(Icons.dark_mode_outlined),
                title: const Text('Mode sombre'),
                value: mode == ThemeMode.dark,
                onChanged: (v) =>
                    themeNotifier.value = v ? ThemeMode.dark : ThemeMode.light,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Container(
            decoration: cardDecoration(context),
            child: ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('À propos'),
              subtitle: const Text('Faso Pulse v1.0.0'),
              onTap: () => showAboutDialog(
                context: context,
                applicationName: 'Faso Pulse',
                applicationVersion: '1.0.0',
                children: const [
                  Text('Actualités et vidéos du Burkina Faso.'),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
