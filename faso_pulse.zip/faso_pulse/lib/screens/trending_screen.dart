import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import '../widgets/section_header.dart';
import '../widgets/trending_card.dart';

class TrendingScreen extends StatelessWidget {
  const TrendingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SectionHeader(title: 'Articles tendance', icon: Icons.trending_up),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(top: 8),
            children: [for (final a in mockArticles) TrendingCard(article: a)],
          ),
        ),
      ],
    );
  }
}
