import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/saved_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/trending_screen.dart';
import 'screens/video_screen.dart';
import 'theme.dart';
import 'widgets/app_header.dart';
import 'widgets/bottom_bar.dart';

void main() => runApp(const FasoPulseApp());

class FasoPulseApp extends StatelessWidget {
  const FasoPulseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
      valueListenable: themeNotifier,
      builder: (_, mode, __) => MaterialApp(
        title: 'Faso Pulse',
        debugShowCheckedModeBanner: false,
        theme: lightTheme,
        darkTheme: darkTheme,
        themeMode: mode,
        home: const MainShell(),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  final _pages = const [
    HomeScreen(),
    TrendingScreen(),
    VideoScreen(),
    SavedScreen(),
    SettingsScreen(),
  ];

  void _go(int i) => setState(() => _index = i);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: kBlue),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text(
                  'Faso Pulse',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ),
            for (int i = 0; i < kTabLabels.length; i++)
              ListTile(
                leading: Icon(kTabIcons[i]),
                title: Text(kTabLabels[i]),
                selected: i == _index,
                onTap: () {
                  Navigator.pop(context);
                  _go(i);
                },
              ),
          ],
        ),
      ),
      body: Column(
        children: [
          AppHeader(onSettings: () => _go(4)),
          Expanded(child: IndexedStack(index: _index, children: _pages)),
        ],
      ),
      bottomNavigationBar: AppBottomBar(index: _index, onTap: _go),
    );
  }
}
