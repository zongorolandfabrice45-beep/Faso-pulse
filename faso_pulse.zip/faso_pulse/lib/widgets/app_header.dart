import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme.dart';
import 'article_search.dart';

class AppHeader extends StatelessWidget {
  final VoidCallback onSettings;
  const AppHeader({super.key, required this.onSettings});

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Container(
        color: kBlue,
        padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
        child: SizedBox(
          height: 64,
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.menu, color: Colors.white, size: 30),
                onPressed: () => Scaffold.of(context).openDrawer(),
              ),
              const Icon(Icons.bolt, color: Colors.white, size: 26),
              const Flexible(
                child: Text(
                  'Faso Pulse',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const Spacer(),
              IconButton(
                icon: const Icon(Icons.search, color: Colors.white, size: 28),
                onPressed: () =>
                    showSearch(context: context, delegate: ArticleSearch()),
              ),
              IconButton(
                icon: const Icon(Icons.settings, color: Colors.white, size: 28),
                onPressed: onSettings,
              ),
              ValueListenableBuilder<ThemeMode>(
                valueListenable: themeNotifier,
                builder: (_, mode, __) => IconButton(
                  icon: Icon(
                    mode == ThemeMode.dark
                        ? Icons.light_mode
                        : Icons.dark_mode_outlined,
                    color: Colors.white,
                    size: 28,
                  ),
                  onPressed: () => themeNotifier.value =
                      mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
