import 'package:flutter/material.dart';
import '../theme.dart';

const List<IconData> kTabIcons = [
  Icons.home_outlined,
  Icons.trending_up,
  Icons.video_library_outlined,
  Icons.bookmark_border,
  Icons.settings_outlined,
];

const List<String> kTabLabels = [
  'Accueil',
  'Tendance',
  'Vidéos',
  'Enregistrés',
  'Paramètres',
];

class AppBottomBar extends StatelessWidget {
  final int index;
  final ValueChanged<int> onTap;
  const AppBottomBar({super.key, required this.index, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = accentOf(context);
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 74,
          child: Row(
            children: [
              for (int i = 0; i < kTabIcons.length; i++)
                Expanded(
                  child: InkWell(
                    onTap: () => onTap(i),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        if (i == index)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 6),
                            decoration: BoxDecoration(
                              color: accent,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Icon(kTabIcons[i], color: Colors.white),
                          )
                        else
                          Icon(kTabIcons[i], size: 28),
                        if (i == index)
                          Padding(
                            padding: const EdgeInsets.only(top: 3),
                            child: FittedBox(
                              fit: BoxFit.scaleDown,
                              child: Text(
                                kTabLabels[i],
                                style: const TextStyle(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
