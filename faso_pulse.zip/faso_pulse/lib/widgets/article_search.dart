import 'package:flutter/material.dart';
import '../data/mock_data.dart';
import 'article_card.dart';

class ArticleSearch extends SearchDelegate<void> {
  ArticleSearch() : super(searchFieldLabel: 'Rechercher un article');

  @override
  List<Widget> buildActions(BuildContext context) => [
        IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
      ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => close(context, null),
      );

  @override
  Widget buildResults(BuildContext context) => _list();

  @override
  Widget buildSuggestions(BuildContext context) => _list();

  Widget _list() {
    final q = query.toLowerCase();
    final results = mockArticles
        .where((a) =>
            a.title.toLowerCase().contains(q) ||
            a.category.toLowerCase().contains(q))
        .toList();
    return ListView(
      children: [for (final a in results) ArticleCard(article: a)],
    );
  }
}
