# Faso Pulse
Après décompression, dans le dossier :
    flutter create .
    flutter pub get
    flutter run
